// Tanımlayıcılar
const {
   MessageActionRow,
   MessageButton,
   MessageEmbed,
   Formatters,
   Permissions,
 } = require("discord.js");
 const { SlashCommandBuilder } = require("@discordjs/builders");
 
 (module.exports = {
   data: new SlashCommandBuilder().setName("Futbol Takip").setDescription("Canlı Futbol İzle"),
 
   async execute(interaction) {
      interaction.reply("Futbol Takip");
   }
 }),
   (module.exports.options = {
     perms: ["0"],
     cooldown: 10,
   });
 